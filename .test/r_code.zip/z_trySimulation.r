#' trySimulation: A package for practicing a simulation study with R.
#'
#' The trySimulation pacakge provides something.
#'
#' @section the functions:
#' the functions something something
#'
#' @docType package
#' @name trySimulation
NULL
